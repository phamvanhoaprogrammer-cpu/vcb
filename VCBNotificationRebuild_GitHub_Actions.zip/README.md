# VCBNotificationRebuild

SwiftUI notification demo/rebuild targeting iOS 15.6+.

## Đặc điểm

- Giữ nguyên title/body do người dùng nhập.
- Không random hóa nội dung.
- Không trim/replace nội dung.
- Không giới hạn ký tự ở UI.
- `TextEditor` phù hợp với nội dung dài.
- Cập nhật trạng thái trên MainActor.
- Dùng UserNotifications.

## Build

Mở project trong Xcode và tạo iOS App project với:
- Interface: SwiftUI
- Language: Swift
- Deployment Target: iOS 15.6+

Sau đó thay file Swift mặc định bằng `VCBNotificationRebuildApp.swift`.

Lưu ý: `UNNotificationRequest` vẫn cần một identifier duy nhất để hệ thống iOS quản lý notification. Identifier này không được đưa vào nội dung người dùng.
