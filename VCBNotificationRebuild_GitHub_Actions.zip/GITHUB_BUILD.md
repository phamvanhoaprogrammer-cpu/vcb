# Build IPA bằng GitHub Actions

GitHub Pages không build iOS. Workflow này dùng GitHub Actions với macOS runner.

## Cách dùng

1. Tạo repository mới trên GitHub.
2. Upload toàn bộ nội dung project này lên repository.
3. Vào tab **Actions**.
4. Chọn workflow **iOS Build**.
5. Nhấn **Run workflow**.
6. Khi chạy xong, vào phần **Artifacts** của workflow run và tải:
   `VCBNotificationRebuild-unsigned`

## Lưu ý

Workflow hiện tạo **unsigned IPA**. IPA này không có chữ ký Apple nên không thể cài bình thường lên iPhone.

Để tạo IPA có thể cài trên thiết bị, cần thêm Apple Developer certificate + provisioning profile vào GitHub Secrets và thay bước signing bằng `xcodebuild archive`/`-exportArchive` hoặc một action signing phù hợp.

Không đưa certificate/private key trực tiếp vào source repository.
