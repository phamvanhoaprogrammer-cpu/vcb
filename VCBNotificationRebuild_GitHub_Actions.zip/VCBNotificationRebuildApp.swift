import SwiftUI
import UserNotifications

@main
struct VCBNotificationRebuildApp: App {
    @UIApplicationDelegateAdaptor(NotificationDelegate.self) private var delegate

    var body: some Scene {
        WindowGroup {
            NotificationFormView()
        }
    }
}

final class NotificationDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil
    ) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        return true
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        [.banner, .sound]
    }
}

@MainActor
final class NotificationFormViewModel: ObservableObject {
    @Published var title = ""
    @Published var body = ""
    @Published var delaySeconds = 1.0
    @Published var status = ""

    func requestPermission() async {
        do {
            let granted = try await UNUserNotificationCenter.current()
                .requestAuthorization(options: [.alert, .sound, .badge])
            status = granted ? "Đã cấp quyền thông báo." : "Chưa được cấp quyền thông báo."
        } catch {
            status = "Lỗi quyền thông báo: \(error.localizedDescription)"
        }
    }

    func schedule() {
        let content = UNMutableNotificationContent()

        // Giữ nguyên nội dung người dùng nhập:
        // không random, không trim, không replace, không giới hạn ký tự.
        content.title = title
        content.body = body
        content.sound = .default

        let interval = max(1.0, delaySeconds)
        let trigger = UNTimeIntervalNotificationTrigger(
            timeInterval: interval,
            repeats: false
        )

        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: trigger
        )

        UNUserNotificationCenter.current().add(request) { [weak self] error in
            Task { @MainActor in
                self?.status = error == nil
                    ? "Đã lên lịch thông báo."
                    : "Lỗi: \(error!.localizedDescription)"
            }
        }
    }
}

struct NotificationFormView: View {
    @StateObject private var model = NotificationFormViewModel()

    var body: some View {
        NavigationStack {
            Form {
                Section("Nội dung") {
                    TextField("Tiêu đề", text: $model.title, axis: .vertical)
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)

                    TextEditor(text: $model.body)
                        .frame(minHeight: 180)
                        .font(.body.monospaced())
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)
                }

                Section("Thời gian") {
                    HStack {
                        Text("Sau")
                        Spacer()
                        TextField(
                            "Giây",
                            value: $model.delaySeconds,
                            format: .number.precision(.fractionLength(0...2))
                        )
                        .keyboardType(.decimalPad)
                        .multilineTextAlignment(.trailing)
                        .frame(width: 100)
                        Text("giây")
                    }
                }

                Section {
                    Button("Xin quyền thông báo") {
                        Task { await model.requestPermission() }
                    }

                    Button("Tạo thông báo") {
                        model.schedule()
                    }
                    .disabled(model.title.isEmpty && model.body.isEmpty)
                }

                if !model.status.isEmpty {
                    Section("Trạng thái") {
                        Text(model.status)
                    }
                }
            }
            .navigationTitle("Thông báo")
        }
    }
}
